/* Implementation of the subroutine subroutine_fnc */

#include "subroutine.h"

/* fill return type */ subroutine_fnc(/* fill in parameters */)
{

  /*
   * fill code with equivalent function to
   *the analyzed program subroutine_fnc
   */

}
