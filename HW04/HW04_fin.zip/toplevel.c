/* Implementation of the subroutine toplevel_fnc */

#include "subroutine.h"

int toplevel_fnc(void)
{

  /*
   * fill in code with equivalent function
   * to the toplevel_fnc function from
   * the assembly program listing.
   */

  /*
   * The code calls function subroutine_fnc
   * and processes its return value.
   * 
   * Then it resturn final result.
   */
}
