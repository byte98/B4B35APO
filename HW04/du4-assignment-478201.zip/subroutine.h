/* Header file which defines type of the subroutine subroutine_fnc */

/* fill return type */ subroutine_fnc(/* fill in parameters */);
